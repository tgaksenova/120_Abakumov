﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Doska.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListObyavPage.xaml
    /// </summary>
    public partial class ListObyavPage : Page
    {
        public ListObyavPage()
        {
            InitializeComponent();
            obyavList.ItemsSource = App.obyavs;
            CategoyCombo.ItemsSource = App.categories.Select(x=>x.category1).ToList();
            OplatCombo.ItemsSource = App.sposoboplats.Select(x=>x.sposoboplat1).ToList();
            SellerCombo.ItemsSource = App.sellers.Select(x=>x.FIO).ToList();
            SposoCombo.ItemsSource = App.typedosts.Select(x=>x.typedost1).ToList();
            if (App.IsAuth)
            {
                addBTN.Visibility = Visibility.Visible;
            }
        }

        private void addBTN_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new AddPage());
        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            List<obyav> obyavs = App.obyavs;
            if (!String.IsNullOrEmpty(Search.Text))
            {
                obyavs = obyavs.Where(x => x.title.Contains(Search.Text)).ToList();
            }
            
            if (SellerCombo.SelectedValue!=null)
            {
                obyavs = obyavs.Where(x => x.sellers.FIO == SellerCombo.SelectedValue.ToString()).ToList();
            }
            
            
            if (SposoCombo.SelectedValue!=null)
            {
                obyavs = obyavs.Where(x => x.typedost.typedost1 == SposoCombo.SelectedValue.ToString()).ToList();
            }
            
           
            
            if (OplatCombo.SelectedValue!=null)
            {
                obyavs = obyavs.Where(x => x.sposoboplat.sposoboplat1 == OplatCombo.SelectedValue.ToString()).ToList();
            }
           
            
            if (CategoyCombo.SelectedValue!=null)
            {
                obyavs = obyavs.Where(x => x.Category.category1 == CategoyCombo.SelectedValue.ToString()).ToList();
            }
            
            

            obyavList.ItemsSource = obyavs;
        }

        private void Sbros_Click(object sender, RoutedEventArgs e)
        {
            Search.Text = "";
            SellerCombo.SelectedValue = null;
            SposoCombo.SelectedValue = null;
            OplatCombo.SelectedValue = null;
            CategoyCombo.SelectedValue = null;
            obyavList.ItemsSource = App.obyavs;
        }
    }
}
