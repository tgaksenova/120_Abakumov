﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Doska.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void LoginBTN_Click(object sender, RoutedEventArgs e)
        { 
            if((!String.IsNullOrEmpty(Login.Text))&&(!String.IsNullOrEmpty(Password.Password)))
            {
                var isLog = App.sellers.Where(x => x.login == Login.Text && x.password == Password.Password).Count();
                if (isLog>0)
                {
                    App.sellerID = App.sellers.Where(x => x.login == Login.Text && x.password == Password.Password).ToList().First().idSeller;
                    App.IsAuth = true;
                    (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new ListObyavPage());
                }
            }
        }

        private void Otmena_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new InitPage());
        }
    }
}
