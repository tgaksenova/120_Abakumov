﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Doska.Pages
{
    /// <summary>
    /// Логика взаимодействия для InitPage.xaml
    /// </summary>
    public partial class InitPage : Page
    {
        public InitPage()
        {
            InitializeComponent();
        }

        private void authBTN_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new AuthPage());

        }

        private void regBTN_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new RegPage());
        }

        private void NoBTN_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new ListObyavPage());

        }
    }
}
