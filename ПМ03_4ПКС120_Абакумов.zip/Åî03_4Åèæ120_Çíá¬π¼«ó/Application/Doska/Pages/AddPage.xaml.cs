﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Doska.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPage.xaml
    /// </summary>
    public partial class AddPage : Page
    {
        public AddPage()
        {
            InitializeComponent();
            Category.ItemsSource = App.categories.Select(x => x.category1).ToList();
            Oplata.ItemsSource = App.sposoboplats.Select(x => x.sposoboplat1).ToList();
            Dostavka.ItemsSource = App.typedosts.Select(x => x.typedost1).ToList();
        }

        private void SaveBTN_Click(object sender, RoutedEventArgs e)
        {
            if ((!String.IsNullOrEmpty(Title.Text))&&Category.SelectedValue!=null&&Oplata.SelectedValue!=null&&Dostavka.SelectedValue!=null)
            {
                Entities entities = new Entities();
                entities.obyav.Add(new obyav() {
                    idcategory = App.categories.Find(x=>x.category1==Category.SelectedValue.ToString()).idCategory,
                    sposoDost = App.typedosts.Find(x=>x.typedost1==Dostavka.SelectedValue.ToString()).idtypedost,
                    title=Title.Text,
                    typeOplat = App.sposoboplats.Find(x=>x.sposoboplat1==Oplata.SelectedValue.ToString()).idsposoboplat,
                    idseller = App.sellerID,
                    publishdate = Date.SelectedDate
                });
                entities.SaveChanges();
                entities = new Entities();
                App.obyavs = entities.obyav.ToList();
                (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new ListObyavPage());
            }
        }

        private void OtmenaBTN_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new ListObyavPage());
        }
    }
}
