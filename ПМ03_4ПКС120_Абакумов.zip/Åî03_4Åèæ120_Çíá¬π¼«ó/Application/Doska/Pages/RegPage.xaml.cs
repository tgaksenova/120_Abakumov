﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Doska.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegPage.xaml
    /// </summary>
    public partial class RegPage : Page
    {
        public RegPage()
        {
            InitializeComponent();
            Region.ItemsSource = App.regions.Select(x => x.region).ToList();
        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            bool isTrue = (!String.IsNullOrEmpty(FIO.Text))&&(!String.IsNullOrEmpty(Phone.Text))&&(!String.IsNullOrEmpty(Email.Text))&&(!String.IsNullOrEmpty(Adress.Text))&& (!String.IsNullOrEmpty(Login.Text))&& (!String.IsNullOrEmpty(Password.Text));
            if (isTrue)
            {
                Entities entities = new Entities();
                entities.sellers.Add(new sellers() {email=Email.Text, adress=Adress.Text, FIO=FIO.Text, login=Login.Text, password=Password.Text, phone=Phone.Text, region=App.regions.Find(x=>x.region==Region.SelectedValue).idregion});
                entities.SaveChanges();
                App.sellers = entities.sellers.ToList();
                (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new AuthPage());
            }
        }
        private void Otmena_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new InitPage());
        }
    }
}
