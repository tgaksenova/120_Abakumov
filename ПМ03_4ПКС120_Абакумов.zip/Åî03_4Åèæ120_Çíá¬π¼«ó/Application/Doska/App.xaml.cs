﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Doska
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static bool IsAuth = false;
        public static int sellerID;
        public static List<Category> categories;
        public static List<obyav> obyavs;
        public static List<regions> regions;
        public static List<sellers> sellers;
        public static List<sposoboplat> sposoboplats;
        public static List<typedost> typedosts;
        public static void LoadBD()
        {
            Entities entities = new Entities();
            categories = entities.Category.ToList();
            obyavs = entities.obyav.ToList();
            regions = entities.regions.ToList();
            sellers = entities.sellers.ToList();
            sposoboplats = entities.sposoboplat.ToList();
            typedosts = entities.typedost.ToList();
        }
    }
}
