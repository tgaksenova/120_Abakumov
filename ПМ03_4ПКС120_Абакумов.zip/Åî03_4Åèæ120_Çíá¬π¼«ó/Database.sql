USE [120_abakumov_exam]
GO
/****** Object:  Table [dbo].[Category]    Script Date: 27.12.2023 12:38:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Category](
	[idCategory] [int] IDENTITY(1,1) NOT NULL,
	[category] [nvarchar](50) NULL,
	[podcategory] [nvarchar](50) NULL,
 CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED 
(
	[idCategory] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[obyav]    Script Date: 27.12.2023 12:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[obyav](
	[idobyav] [int] IDENTITY(1,1) NOT NULL,
	[publishdate] [date] NULL,
	[idseller] [int] NULL,
	[idcategory] [int] NULL,
	[title] [nvarchar](max) NULL,
	[typeOplat] [int] NULL,
	[sposoDost] [int] NULL,
 CONSTRAINT [PK_obyav] PRIMARY KEY CLUSTERED 
(
	[idobyav] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[regions]    Script Date: 27.12.2023 12:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[regions](
	[idregion] [int] IDENTITY(1,1) NOT NULL,
	[region] [nvarchar](max) NULL,
 CONSTRAINT [PK_regions] PRIMARY KEY CLUSTERED 
(
	[idregion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[sellers]    Script Date: 27.12.2023 12:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[sellers](
	[idSeller] [int] IDENTITY(1,1) NOT NULL,
	[region] [int] NULL,
	[FIO] [nvarchar](max) NULL,
	[phone] [nchar](20) NULL,
	[email] [nchar](100) NULL,
	[adress] [nvarchar](max) NULL,
	[login] [nvarchar](max) NULL,
	[password] [nvarchar](max) NULL,
 CONSTRAINT [PK_sellers] PRIMARY KEY CLUSTERED 
(
	[idSeller] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[sposoboplat]    Script Date: 27.12.2023 12:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[sposoboplat](
	[idsposoboplat] [int] IDENTITY(1,1) NOT NULL,
	[sposoboplat] [nvarchar](max) NULL,
 CONSTRAINT [PK_sposoboplat] PRIMARY KEY CLUSTERED 
(
	[idsposoboplat] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[typedost]    Script Date: 27.12.2023 12:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[typedost](
	[idtypedost] [int] IDENTITY(1,1) NOT NULL,
	[typedost] [nvarchar](max) NULL,
 CONSTRAINT [PK_typedost] PRIMARY KEY CLUSTERED 
(
	[idtypedost] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Category] ON 
GO
INSERT [dbo].[Category] ([idCategory], [category], [podcategory]) VALUES (1, N'Электроника', N'Видеокарты')
GO
INSERT [dbo].[Category] ([idCategory], [category], [podcategory]) VALUES (2, N'Мебель', N'Диваны')
GO
INSERT [dbo].[Category] ([idCategory], [category], [podcategory]) VALUES (3, N'Литература', N'Книги')
GO
INSERT [dbo].[Category] ([idCategory], [category], [podcategory]) VALUES (4, N'Литература', N'Журналы')
GO
INSERT [dbo].[Category] ([idCategory], [category], [podcategory]) VALUES (5, N'Пищ. продукты', N'Еда')
GO
SET IDENTITY_INSERT [dbo].[Category] OFF
GO
SET IDENTITY_INSERT [dbo].[obyav] ON 
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (1, CAST(N'2023-12-15' AS Date), 1, 1, N'Продукт 1', 1, 3)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (2, CAST(N'2023-12-15' AS Date), 4, 1, N'Продукт 2', 2, 3)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (3, CAST(N'2023-12-15' AS Date), 5, 2, N'Продукт 3', 1, 3)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (4, CAST(N'2023-12-15' AS Date), 3, 2, N'Продукт 4', 3, 1)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (5, CAST(N'2023-12-15' AS Date), 2, 3, N'Продукт 5', 3, 2)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (7, CAST(N'2023-12-27' AS Date), 7, 1, N'aaa', 1, 1)
GO
INSERT [dbo].[obyav] ([idobyav], [publishdate], [idseller], [idcategory], [title], [typeOplat], [sposoDost]) VALUES (8, CAST(N'2023-12-27' AS Date), 7, 1, N'aaa', 1, 1)
GO
SET IDENTITY_INSERT [dbo].[obyav] OFF
GO
SET IDENTITY_INSERT [dbo].[regions] ON 
GO
INSERT [dbo].[regions] ([idregion], [region]) VALUES (1, N'Москва')
GO
INSERT [dbo].[regions] ([idregion], [region]) VALUES (2, N'Московская область')
GO
INSERT [dbo].[regions] ([idregion], [region]) VALUES (3, N'Белгородская область')
GO
INSERT [dbo].[regions] ([idregion], [region]) VALUES (4, N'Воронежская область')
GO
INSERT [dbo].[regions] ([idregion], [region]) VALUES (5, N'Нижегородская область')
GO
SET IDENTITY_INSERT [dbo].[regions] OFF
GO
SET IDENTITY_INSERT [dbo].[sellers] ON 
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (1, 1, N'Иванов Иван Иванович', N'+7(999)999-99-99    ', N'a@mail.con                                                                                          ', N'Москва, ул. Советская 3', N'login1', N'password1')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (2, 2, N'Сироткин Иван Иванович', N'+7(999)999-99-99    ', N'a@mail.con                                                                                          ', N'Москва, ул. Советская 3', N'login2', N'password2')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (3, 5, N'Квасов Иван Иванович', N'+7(999)999-99-99    ', N'a@mail.con                                                                                          ', N'Москва, ул. Советская 3', N'login3', N'password3')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (4, 3, N'Дояркин Иван Иванович', N'+7(999)999-99-99    ', N'a@mail.con                                                                                          ', N'Москва, ул. Советская 3', N'login4', N'password4')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (5, 4, N'Шебекин Иван Иванович', N'+7(999)999-99-99    ', N'a@mail.con                                                                                          ', N'Москва, ул. Советская 3', N'login5', N'password5')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (6, 1, N'adsad', N'sdafa               ', N'sadfsa                                                                                              ', N'asdf', N'sdafdsa', N'dsafsda')
GO
INSERT [dbo].[sellers] ([idSeller], [region], [FIO], [phone], [email], [adress], [login], [password]) VALUES (7, 1, N'aa', N'aaa                 ', N'aaa                                                                                                 ', N'aaa', N'aaa', N'aaa')
GO
SET IDENTITY_INSERT [dbo].[sellers] OFF
GO
SET IDENTITY_INSERT [dbo].[sposoboplat] ON 
GO
INSERT [dbo].[sposoboplat] ([idsposoboplat], [sposoboplat]) VALUES (1, N'Наличные')
GO
INSERT [dbo].[sposoboplat] ([idsposoboplat], [sposoboplat]) VALUES (2, N'Перевод')
GO
INSERT [dbo].[sposoboplat] ([idsposoboplat], [sposoboplat]) VALUES (3, N'Терминал')
GO
SET IDENTITY_INSERT [dbo].[sposoboplat] OFF
GO
SET IDENTITY_INSERT [dbo].[typedost] ON 
GO
INSERT [dbo].[typedost] ([idtypedost], [typedost]) VALUES (1, N'Курьер')
GO
INSERT [dbo].[typedost] ([idtypedost], [typedost]) VALUES (2, N'Почта')
GO
INSERT [dbo].[typedost] ([idtypedost], [typedost]) VALUES (3, N'Личная доставка')
GO
SET IDENTITY_INSERT [dbo].[typedost] OFF
GO
ALTER TABLE [dbo].[obyav]  WITH CHECK ADD  CONSTRAINT [FK_obyav_Category] FOREIGN KEY([idcategory])
REFERENCES [dbo].[Category] ([idCategory])
GO
ALTER TABLE [dbo].[obyav] CHECK CONSTRAINT [FK_obyav_Category]
GO
ALTER TABLE [dbo].[obyav]  WITH CHECK ADD  CONSTRAINT [FK_obyav_sellers] FOREIGN KEY([idseller])
REFERENCES [dbo].[sellers] ([idSeller])
GO
ALTER TABLE [dbo].[obyav] CHECK CONSTRAINT [FK_obyav_sellers]
GO
ALTER TABLE [dbo].[obyav]  WITH CHECK ADD  CONSTRAINT [FK_obyav_sposoboplat] FOREIGN KEY([typeOplat])
REFERENCES [dbo].[sposoboplat] ([idsposoboplat])
GO
ALTER TABLE [dbo].[obyav] CHECK CONSTRAINT [FK_obyav_sposoboplat]
GO
ALTER TABLE [dbo].[obyav]  WITH CHECK ADD  CONSTRAINT [FK_obyav_typedost] FOREIGN KEY([sposoDost])
REFERENCES [dbo].[typedost] ([idtypedost])
GO
ALTER TABLE [dbo].[obyav] CHECK CONSTRAINT [FK_obyav_typedost]
GO
ALTER TABLE [dbo].[sellers]  WITH CHECK ADD  CONSTRAINT [FK_sellers_regions] FOREIGN KEY([region])
REFERENCES [dbo].[regions] ([idregion])
GO
ALTER TABLE [dbo].[sellers] CHECK CONSTRAINT [FK_sellers_regions]
GO
